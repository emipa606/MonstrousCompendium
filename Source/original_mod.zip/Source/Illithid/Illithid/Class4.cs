﻿// RimWorld.PawnKindDefOf
using RimWorld;
using Verse;

[DefOf]
public static class PawnKindDefOf
{
    public static PawnKindDef Deviljho;
    public static PawnKindDef Purpleworm;
}
